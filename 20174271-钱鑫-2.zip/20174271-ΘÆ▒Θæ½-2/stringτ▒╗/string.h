#pragma once
#include <iostream>
using namespace std;

class String
{
public:
	String();											 // default constructor
	String(int, char);								     // ordinary constructor
	String(const char*);								 // ordinary constructor
	String(const String&);							     // copy constructor
	~String();										     // destructor
	String& operator=(const char*);							 // override of "="
	String& operator=(const String&);					 //implement function of object assignment
	char& operator[](int );							     //override of "[]"
	const char& operator[](int i) const;				//override of "[]" for constant index
	String& operator+=(const String&);				     //add between two objects 
	String& operator+=(const char*);						//add between two strings
	friend ostream& operator<<(ostream& out, String& s);  //override of "<<"
	friend istream& operator>>(istream& in, String& s);     //override of ">>"
	friend bool operator<(const String&, const String&);    //override of "<"
	friend bool operator>(const String&, const String&);    //override of ">"
	friend bool operator==(const String&, const String&);   //override of "=="
	friend bool operator!=(const String&, const String&);    //override of "!="
	char* getString() const;
	int getSize() const;
private:
	int size;			// Size signifies the total length of the string
	char* value;		 // Character pointer denotes the string
};

