#include "string.h"

// default constructor
String::String():size(0) {   
	value = new char[1];
	*value = '\0';
}

//ordinary constructor
String::String(int size, char character){
	this->size = size;
	value = new char[size + 1];
	char* temp = value;
	while (size--)
	{
		*temp++ = character;
	}
	*temp = '\0';
}

//ordinary constructor
String::String(const char* source){
	if (source == nullptr)
	{
		value = new char[1];
		*value = '\0';
		size = 0;
	}
	else{
		this->size = strlen(source);
		value = new char[size + 1];
		strcpy_s(value, size + 1, source); //duplicate process
	}
}

// copy constructor
String::String(const String& s)
{
	size = s.size;
	value = new char[s.size + 1];
	strcpy_s(value, s.size + 1, s.value); //duplicate process
}

// destructor
String::~String()
{ 
	if (value != nullptr){
		delete[] value;
		value = nullptr;
		this->size = 0;
	}
}

//override of "="
String& String::operator=(const char* string){
	if (value != nullptr)
		delete[] value;
	this->size = strlen(string);
	value = new char[size + 1];
	strcpy_s(value, size + 1, string);
	return *this;
}

//implement function of object assignment
String& String::operator=(const String& s){
	if (this == &s)       return *this;
	if (value != nullptr) delete[] value;
	size = s.size;
	value = new char[size + 1];
	strcpy_s(value, size + 1, s.value);
	return *this;
}

//override of "[]"
char& String::operator[](int i){
	return value[i];
}

//override of "[]" for constant index
const char& String::operator[](int i) const
{
	return value[i];
}

//add between two objects 
String& String::operator+=(const String& s){
	int len = size + s.size + 1;
	char* temp = value;
	value = new char[len];
	strcpy_s(value, size + 1, temp);
	strcat_s(value, len, s.value);
	delete[] temp;
	size = len - 1;
	return *this;
}

//add between two strings
String& String::operator+=(const char* s){
	if (s == nullptr)
	{
		return *this;
	}
	int len = size + strlen(s) + 1;
	char* temp = value;
	value = new char[len];
	strcpy_s(value, size + 1, temp);
	strcat_s(value, len, s);
	delete[] temp;
	size = len - 1;
	return *this;
}

ostream& operator<<(ostream& out, String& s){
	for (int i = 0; i < s.size; i++)
		out << s[i] << " ";
	return out;
}

istream& operator>>(istream& in, String& s){
	char p[50];
	in.getline(p, 50);     
	s = p;                  
	return in;
}

//override of "<"
bool operator<(const String& left, const String& right) {
	int i = 0;
	while (left[i] == right[i] && left[i] != 0 && right[i] != 0)
		i++;
	return left[i] - right[i] < 0 ? true : false;
}

//override of ">"
bool operator>(const String& left, const String& right) {
	int i = 0;
	while (left[i] == right[i] && left[i] != 0 && right[i] != 0)
		i++;
	return left[i] - right[i] > 0 ? true : false;
}

//override of "=="
bool operator==(const String& left, const String& right){
	if (left.size != right.size)
		return false;
	for (int i = 0; i < left.size; i++)
	{
		if (left.value[i] != right.value[i])
			return false;
	}
	return true;
}

//override of "!="
bool operator!=(const String& left, const String& right){
	if (left.size != right.size)
		return true;
	for (int i = 0; i < left.size; i++)
	{
		if (left.value[i] != right.value[i])
			return true;
	}
	return false;
}

char* String::getString() const{
	if (this->size > 0) return value;
	else return nullptr;
}

int String::getSize()const {
	return this->size;
}