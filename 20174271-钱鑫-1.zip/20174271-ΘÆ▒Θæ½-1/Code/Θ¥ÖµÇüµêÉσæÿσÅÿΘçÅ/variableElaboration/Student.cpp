#include "Student.h"

Student::Student() {
	name = "";
	studentID = "";
	gender = false;
	//default constructor
} 

Student::Student(string name, string stuID, bool gender)
	:name(name), studentID(stuID), gender(gender)
{
	cout << "������" << getName() << " " << "ѧ�ţ�" << getstudentID()<<" �Ա�";
	if (gender) cout << "male" << endl;
	else cout << "female" << endl;
	this->studentCount++;
}// constructor

Student::~Student() {
	// destructor
}

void Student::setName(string name) {
	this->name = name;
}

string Student::getName()const {
	return name;
}

void Student::setstudentID(string stuID) {
	this->studentID = stuID;
}

string Student::getstudentID()const {
	return studentID;
}

void Student::setgender(bool gen) {
	this->gender = gen;
}

bool Student::getGender()const {
	return gender;
}

int Student::getStudentCount()const {
	return studentCount;  
}

int Student::studentCount;