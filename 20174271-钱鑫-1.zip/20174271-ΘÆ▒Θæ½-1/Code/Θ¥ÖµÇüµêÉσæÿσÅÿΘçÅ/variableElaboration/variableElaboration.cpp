﻿// variableElaboration.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include "Student.h"

using namespace std;
int main()
{
    Student A("Pant", "20204270", true);
    cout << "学生总人数是" << A.getStudentCount() << endl;
    cout << endl;

    Student B("Smith", "20204272", true);
    cout << "学生总人数是" << B.getStudentCount() << endl;
    cout << endl;

    Student C("Ocean", "20204273", false);
    cout << "学生总人数是" << C.getStudentCount() << endl;
    cout << endl;

    Student D("duke", "20204273", false);
	if (B.getStudentCount() == C.getStudentCount()) {
		cout << "注册一个新同学后，学生总人数是" << A.getStudentCount() << endl;
	}
    system("pause");
    return 0;
}


