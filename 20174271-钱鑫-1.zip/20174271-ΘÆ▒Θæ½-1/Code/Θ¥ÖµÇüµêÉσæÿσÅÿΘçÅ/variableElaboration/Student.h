#pragma once

#include <iostream>
#include <string>
using namespace std;

#ifndef STUDENT_H
#define STUDENT_H
// class of student signifies total students at a specific high school
class Student
{
	static int studentCount; // default = 0
public:
	Student();
	Student(string, string, bool);
	~Student();

	int getStudentCount()const;

	void setName(string);
	string getName()const;

	void setstudentID(string);
	string getstudentID()const;

	void setgender(bool);
	bool getGender()const;

private:
	string name;
	string studentID;
	bool gender;
};

#endif 