﻿// DemonstrationForOthers.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include "head.h"

/*  staticGlobal     signifies 静态全局变量
    staticLocal      presents  静态局部变量
    globalVariable   denotes   全局变量 */
using namespace std;

static int staticGlobal = -1;

void selfIncrement() {
    int local = 0;
    static int staticLocal;
    local++;
    staticLocal++;
    cout << "the value of the Local is " << local ;
    cout << ", while the value of the staticLocal is " << staticLocal << endl;
}
int main()
{
    int staticGlobal = 1;
    cout << "the value of the global variable is " << globalVariable << endl;

    selfIncrement();
    selfIncrement();
    selfIncrement();

    cout << "the staticGlobal located in main() is " << staticGlobal << endl;
    cout << "the staticGlobal situated outside the main() is " << ::staticGlobal << endl;

    system("pause");
    return 0;
}


