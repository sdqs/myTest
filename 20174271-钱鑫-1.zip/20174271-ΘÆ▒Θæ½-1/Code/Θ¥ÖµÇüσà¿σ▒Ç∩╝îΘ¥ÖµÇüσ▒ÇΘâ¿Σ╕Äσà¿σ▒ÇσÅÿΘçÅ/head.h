#pragma once
#ifndef HEAD_H
#define HEAD_H

extern int globalVariable = 10;

#endif // !HEAD_H

